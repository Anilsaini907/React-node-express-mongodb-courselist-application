// Importing required modules
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Course = require('./models/course');
const User= require('./models/user');
const app = express();
const cors = require('cors');
app.use(cors());

// Connecting to MongoDB
mongoose.connect('mongodb://0.0.0.0:27017/coursesDB', { useNewUrlParser: true,
 useUnifiedTopology: true })
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch((err) => {
        console.error('Error connecting to MongoDB:', err.message);
    });

    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));

// 4. Implement user authentication endpoints
// Register a new user
app.post('/register', async (req, res) => {
    // console.log(req.body);
    try {
        const { username,} = req.body;
        const password = await bcrypt.hash(req.body.password, 10);
        const user = new User({ username, password });
        await user.save();
        res.status(201).send('User created successfully');
    } catch (error) {
        res.status(500).send(error.message);
    }
});

// Login
 app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username});
    if (!user) {
        res.status(401).send('Invalid username');
    } else {
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (passwordMatch) {
            const token = jwt.sign({ username: user.username }, 'secretkey');
            res.status(200).json({ username,token });
        }
        else{
            res.status(401).send('Invalid password');
        }
        
    }
});

// 5. Verify JWT tokens
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.status(401).send('Token is missing');

    jwt.verify(token, 'secretkey', (err, user) => {
        if (err) return res.status(403).send('Invalid token');
        req.user = user;
        next();
    });
}

// Route to create a new course
app.post('/courses',authenticateToken, async (req, res) => {
    try {
        const course = new Course(req.body);
        await course.save();
        res.status(201).send(course);
    } catch (err) {
        res.status(400).send(err);
    }
});

// Route to edit a course by its ID
app.put('/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);
    const { name, price ,description,status} = req.body;
    // Find the course with the provided ID
    const course = Course.findOne({_id:courseId});
    if (!course) {
        return res.status(404).json({ error: 'Course not found' });
    }
    // Update the course's properties
    if (name) {
        course.name = name;
    }
    if (price) {
        course.price = price;
    }
    if (description) {
        course.description = description;
    }
    if (status) {
        course.price = status;
    }
    // Send a response with the updated course
    res.json({ message: 'Course updated successfully', course });
});

// Route to get all courses
app.get('/courses',authenticateToken, async (req, res) => {
    try {
        const courses = await Course.find();
        res.send(courses);
    } catch (err) {
        res.status(500).send(err);
    }
});

// Starting the server
const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
