// Importing required modules
const mongoose = require('mongoose');

// Defining the course schema
const courseSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    price: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    status: {
        type: String,
        enum: ['LIVE', 'ONLINE'], // Assuming there are two possible statuses: draft and published
        default: 'LIVE' // Default status is set to 'draft'
    }
});

// Creating a model from the schema
const Course = mongoose.model('Course', courseSchema);

module.exports = Course;
