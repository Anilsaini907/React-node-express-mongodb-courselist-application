// Importing required modules
const mongoose = require('mongoose');
// 3. Define your user schema
const userSchema = new mongoose.Schema({
    username: String,
    password: String
});

const User = mongoose.model('User', userSchema);

module.exports = User;