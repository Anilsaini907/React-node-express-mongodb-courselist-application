import React, { useState, useEffect } from 'react';
import axiosInstance from '../axiosInstance'; //Global instance
import './CourseList.css';


const CourseList = (onEdit) => {
    const [courses, setCourses] = useState([]);
    useEffect(() => {
        // Fetch course data from the server when the component mounts
        fetchCourses();
    }, []);
    const fetchCourses = async () => {
        try {
            // Make an HTTP GET request to fetch course data from the server
            const response = await axiosInstance.get('http://localhost:8000/courses');
            console.log(response.data);
            // Set the fetched course data in the state
            setCourses(response.data);
        } catch (error) {
            console.error('Error fetching courses:', error);
        }
    };


    return (

        // table course

        <div className="course-list-container">
            <h2>Course List</h2>
            <div className="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {courses.map(course => (
                            <tr key={course._id}>
                                <td>{course.name}</td>
                                <td>{course.price}</td>
                                <td>{course.description}</td>
                                <td>{course.status}</td>
                    <td  className='coloumn'><button  className="edit-button">Edit</button></td>
                 <td className='coloumn'><button className="delete-button">Delete</button></td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>

    );
};

export default CourseList;
