import React from 'react';
import './Header.css';

const Header = ({ user, onLogout }) => {
    return (
        <div className="header">
            <div className="logo">Your Logo</div>
            <div className="user-info">
                {user && (
                    <>
                        <span className="username">{user.username}</span>
                        <button onClick={onLogout}>Logout</button>
                    </>
                )}
            </div>
        </div>
    );
};

export default Header;
