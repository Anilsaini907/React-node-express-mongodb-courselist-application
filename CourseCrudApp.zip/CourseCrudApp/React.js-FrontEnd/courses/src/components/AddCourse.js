import React, { useState } from 'react';
import './AddCourse.css'; // Import CSS for styling
import axiosInstance from '../axiosInstance'; //Global instance

const AddCourse = () => {
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [description, setDescription] = useState('');
    const [status, setStatus] = useState('');

    const handleSubmit = async(e) => {
        e.preventDefault();
        console.log({ name, price, description, status });
        // Here, you can handle form submission, such as sending the data to the server
        try {
            // Make an HTTP POST request to your server to authenticate the user
            const response = await axiosInstance.post('http://localhost:8000/courses', 
            { name, price, description, status });
            // Extract token from the response
            const data = response.data;
            if(data){
        // Reload the page after successful form submission
            window.location.reload();
            }
            console.log(data);
            
        } catch (error) {
            console.log(error);
        }
        
    };

    return (
        <div className="add-course-container">
            <h2>Add Course</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div>
                    <label>Price:</label>
                    <input type="text" value={price} onChange={(e) => setPrice(e.target.value)} />
                </div>
                <div>
                    <label>Description:</label>
                    <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
                </div>
                <div>
                    <label>Status:['LIVE', 'ONLINE'] Only</label>
                    <input type="text" value={status} onChange={(e) => setStatus(e.target.value)} />
                </div>
                <button type="submit">Add Course</button>
            </form>
        </div>
    );
};

export default AddCourse;
