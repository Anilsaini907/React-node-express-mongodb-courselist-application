
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes,useNavigate } from 'react-router-dom';
import LoginForm from '../src/components/LoginForm.js'; // Assuming you have created the LoginForm component
import CourseList from '../src/components/CourseList.js';
import Header from '../src/components/Header.js';
import AddCourse from '../src/components/AddCourse.js';
const App = () => {
    const [token, setToken] = useState(null);
    // const navigate = useNavigate();
 
    const handleEdit = (editedCourse) => {
      console.log('Editing course:', editedCourse);
      // Here you can implement your logic to open a modal or navigate to an edit page
  };
    return (
        <Router>
            <div>
            <div style={{margin:20}}>  <Header /></div>
            <div style={{margin:20}}><AddCourse /></div>
            
            {/* <div style={{width:120,margin:20}}><button onClick={handleButtonClick} 
            className="edit-button">Add Course</button></div> */}
                <Routes>
                    
                    <Route path='/' element={<LoginForm />} />
                    <Route path="/course" element={<CourseList onEdit={handleEdit}/>} >
                    {/* <Route path='/addcourse' element={ <AddCourse />} /> */}
                    </Route>
                    
                </Routes>
            </div>
        </Router>
    );
};


export default App;
